/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author nguyenductuan
 */
public class SessionData {
    public static int maTaiKhoan;
    public static String TDN;
    public static String MK;
    public static String role;
    public static boolean YeuCauHuy;

    public static int getMaTaiKhoan() {
        return maTaiKhoan;
    }

    public static void setMaTaiKhoan(int maTaiKhoan) {
        SessionData.maTaiKhoan = maTaiKhoan;
    }

    public static String getTDN() {
        return TDN;
    }

    public static void setTDN(String TDN) {
        SessionData.TDN = TDN;
    }

    public static String getMK() {
        return MK;
    }

    public static void setMK(String MK) {
        SessionData.MK = MK;
    }

    public static String getRole() {
        return role;
    }

    public static void setRole(String role) {
        SessionData.role = role;
    }
    public static int getMaTKDangNhap() {
        return maTaiKhoan; // hoặc biến tương ứng trong SessionData
    }
    
    
}
