/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author nguyenductuan
 */
public class ThongTinVe {
    private int maVe;
    private String pnr;
    private String tenTau;
    private String soGhe;
    private String gioDi;
    private Date ngayDat;
    private String gaDi;
    private String gaDen;
    private BigDecimal giaVe;
    private String trangThai;

    public ThongTinVe() {
    }

    public ThongTinVe(int maVe, String pnr, String tenTau, String soGhe, String gioDi, Date ngayDat, String gaDi, String gaDen, BigDecimal giaVe, String trangThai) {
        this.maVe = maVe;
        this.pnr = pnr;
        this.tenTau = tenTau;
        this.soGhe = soGhe;
        this.gioDi = gioDi;
        this.ngayDat = ngayDat;
        this.gaDi = gaDi;
        this.gaDen = gaDen;
        this.giaVe = giaVe;
        this.trangThai = trangThai;
    }

    public int getMaVe() {
        return maVe;
    }

    public void setMaVe(int maVe) {
        this.maVe = maVe;
    }

    public String getPnr() {
        return pnr;
    }

    public void setPnr(String pnr) {
        this.pnr = pnr;
    }

    public String getTenTau() {
        return tenTau;
    }

    public void setTenTau(String tenTau) {
        this.tenTau = tenTau;
    }

    public String getSoGhe() {
        return soGhe;
    }

    public void setSoGhe(String soGhe) {
        this.soGhe = soGhe;
    }

    public String getGioDi() {
        return gioDi;
    }

    public void setGioDi(String gioDi) {
        this.gioDi = gioDi;
    }

    public Date getNgayDat() {
        return ngayDat;
    }

    public void setNgayDat(Date ngayDat) {
        this.ngayDat = ngayDat;
    }

    public String getGaDi() {
        return gaDi;
    }

    public void setGaDi(String gaDi) {
        this.gaDi = gaDi;
    }

    public String getGaDen() {
        return gaDen;
    }

    public void setGaDen(String gaDen) {
        this.gaDen = gaDen;
    }

    public BigDecimal getGiaVe() {
        return giaVe;
    }

    public void setGiaVe(BigDecimal giaVe) {
        this.giaVe = giaVe;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }
    
}
