package Model;

public class BaoCao {
    private int soVeDaBan;
    private int soGheConLai;
    private double tongDoanhThu;

    public BaoCao(int soVeDaBan, int soGheConLai, double tongDoanhThu) {
        this.soVeDaBan = soVeDaBan;
        this.soGheConLai = soGheConLai;
        this.tongDoanhThu = tongDoanhThu;
    }

    public int getSoVeDaBan() { return soVeDaBan; }
    public int getSoGheConLai() { return soGheConLai; }
    public double getTongDoanhThu() { return tongDoanhThu; }
}
