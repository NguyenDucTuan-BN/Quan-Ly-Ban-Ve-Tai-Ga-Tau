/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.Date;

/**
 *
 * @author nguyenductuan
 */
public class HanhKhach {

    private int MaHk;
    private Integer MaTK;
    private String HoTen, CCCD;
    private Date NgaySinh;
    private String GioiTinh, DiaChi, SDT;

    public HanhKhach(String HoTen, String CCCD, Date NgaySinh, String GioiTinh, String DiaChi, String SDT, int MaTK) {
        this.HoTen = HoTen;
        this.CCCD = CCCD;
        this.NgaySinh = NgaySinh;
        this.GioiTinh = GioiTinh;
        this.DiaChi = DiaChi;
        this.SDT = SDT;
        this.MaTK = MaTK;
    }

    public HanhKhach() {
    }

    public HanhKhach(int MaHk, Integer MaTK, String HoTen, String CCCD, Date NgaySinh, String GioiTinh, String DiaChi, String SDT) {
        this.MaHk = MaHk;
        this.MaTK = MaTK;
        this.HoTen = HoTen;
        this.CCCD = CCCD;
        this.NgaySinh = NgaySinh;
        this.GioiTinh = GioiTinh;
        this.DiaChi = DiaChi;
        this.SDT = SDT;
    }

    public HanhKhach(String HoTen, String CCCD, Date NgaySinh, String GioiTinh, String DiaChi, String SDT) {
        this.HoTen = HoTen;
        this.CCCD = CCCD;
        this.NgaySinh = NgaySinh;
        this.GioiTinh = GioiTinh;
        this.DiaChi = DiaChi;
        this.SDT = SDT;
    }

    public HanhKhach(String HoTen, String CCCD, String SDT) {
        this.HoTen = HoTen;
        this.CCCD = CCCD;
        this.SDT = SDT;
    }
    
    
    
    

    public int getMaHk() {
        return MaHk;
    }

    public void setMaHk(int MaHk) {
        this.MaHk = MaHk;
    }

    public Integer getMaTK() {
        return MaTK;
    }

    public void setMaTK(Integer MaTK) {
        this.MaTK = MaTK;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public String getCCCD() {
        return CCCD;
    }

    public void setCCCD(String CCCD) {
        this.CCCD = CCCD;
    }

    public Date getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(Date NgaySinh) {
        this.NgaySinh = NgaySinh;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

}
