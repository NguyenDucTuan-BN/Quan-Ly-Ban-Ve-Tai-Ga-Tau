/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.math.BigDecimal;
import java.sql.Time;
import java.util.Date;

/**
 *
 * @author LEGION 5
 */
public class ChuyenTau {

    private int MaChuyen;
    private String Tuyen, Tau;
    private Date NgayKhoiHanh;
    private java.sql.Time GioKhoiHanh;
    private String LoaiVe;
    private BigDecimal GiaVe;

    public ChuyenTau() {
    }

    public ChuyenTau(int MaChuyen, String Tuyen, String Tau, Date NgayKhoiHanh, Time GioKhoiHanh, String LoaiVe, BigDecimal GiaVe) {
        this.MaChuyen = MaChuyen;
        this.Tuyen = Tuyen;
        this.Tau = Tau;
        this.NgayKhoiHanh = NgayKhoiHanh;
        this.GioKhoiHanh = GioKhoiHanh;
        this.LoaiVe = LoaiVe;
        this.GiaVe = GiaVe;
    }

    public ChuyenTau(String Tuyen, String Tau, Date NgayKhoiHanh, Time GioKhoiHanh, String LoaiVe, BigDecimal GiaVe) {
        this.Tuyen = Tuyen;
        this.Tau = Tau;
        this.NgayKhoiHanh = NgayKhoiHanh;
        this.GioKhoiHanh = GioKhoiHanh;
        this.LoaiVe = LoaiVe;
        this.GiaVe = GiaVe;
    }
    

    public int getMaChuyen() {
        return MaChuyen;
    }

    public void setMaChuyen(int MaChuyen) {
        this.MaChuyen = MaChuyen;
    }

    public String getTuyen() {
        return Tuyen;
    }

    public void setTuyen(String Tuyen) {
        this.Tuyen = Tuyen;
    }

    public String getTau() {
        return Tau;
    }

    public void setTau(String Tau) {
        this.Tau = Tau;
    }

    public Date getNgayKhoiHanh() {
        return NgayKhoiHanh;
    }

    public void setNgayKhoiHanh(Date NgayKhoiHanh) {
        this.NgayKhoiHanh = NgayKhoiHanh;
    }

    public Time getGioKhoiHanh() {
        return GioKhoiHanh;
    }

    public void setGioKhoiHanh(Time GioKhoiHanh) {
        this.GioKhoiHanh = GioKhoiHanh;
    }

    public String getLoaiVe() {
        return LoaiVe;
    }

    public void setLoaiVe(String LoaiVe) {
        this.LoaiVe = LoaiVe;
    }

    public BigDecimal getGiaVe() {
        return GiaVe;
    }

    public void setGiaVe(BigDecimal GiaVe) {
        this.GiaVe = GiaVe;
    }
}
