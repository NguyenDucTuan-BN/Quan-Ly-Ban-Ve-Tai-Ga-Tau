/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.Date;

/**
 *
 * @author LEGION 5
 */
public class Ve {

    private int MaVe, MaChuyen, MaHK;
    private String SoGhe, LoaiVe, PNR;
    private Date NgayDat;
    private String TrangThai;

    public Ve() {
    }

    
    public Ve(int MaChuyen, String SoGhe, String LoaiVe, String PNR, Date NgayDat, String TrangThai, int MaHK) {
        this.MaChuyen = MaChuyen;
        this.SoGhe = SoGhe;
        this.LoaiVe = LoaiVe;
        this.PNR = PNR;
        this.NgayDat = NgayDat;
        this.TrangThai = TrangThai;
        this.MaHK = MaHK;
    }

    public Ve(int MaChuyen, String SoGhe, String LoaiVe, String PNR, Date NgayDat, String TrangThai) {
        this.MaChuyen = MaChuyen;
        this.SoGhe = SoGhe;
        this.LoaiVe = LoaiVe;
        this.PNR = PNR;
        this.NgayDat = NgayDat;
        this.TrangThai = TrangThai;
    }

    public Ve(int MaVe, int MaChuyen, int MaHK, String SoGhe, String LoaiVe, String PNR, Date NgayDat, String TrangThai) {
        this.MaVe = MaVe;
        this.MaChuyen = MaChuyen;
        this.MaHK = MaHK;
        this.SoGhe = SoGhe;
        this.LoaiVe = LoaiVe;
        this.PNR = PNR;
        this.NgayDat = NgayDat;
        this.TrangThai = TrangThai;
    }

    public int getMaVe() {
        return MaVe;
    }

    public void setMaVe(int MaVe) {
        this.MaVe = MaVe;
    }

    public int getMaChuyen() {
        return MaChuyen;
    }

    public void setMaChuyen(int MaChuyen) {
        this.MaChuyen = MaChuyen;
    }

    public int getMaHK() {
        return MaHK;
    }

    public void setMaHK(int MaHK) {
        this.MaHK = MaHK;
    }

    public String getSoGhe() {
        return SoGhe;
    }

    public void setSoGhe(String SoGhe) {
        this.SoGhe = SoGhe;
    }

    public String getLoaiVe() {
        return LoaiVe;
    }

    public void setLoaiVe(String LoaiVe) {
        this.LoaiVe = LoaiVe;
    }

    public String getPNR() {
        return PNR;
    }

    public void setPNR(String PNR) {
        this.PNR = PNR;
    }

    public Date getNgayDat() {
        return NgayDat;
    }

    public void setNgayDat(Date NgayDat) {
        this.NgayDat = NgayDat;
    }

    public String getTrangThai() {
        return TrangThai;
    }

    public void setTrangThai(String TrangThai) {
        this.TrangThai = TrangThai;
    }

}
