package Model;
import java.sql.Date;
import java.sql.Time;

public class Chuyen {
    private String maChuyen;
    private String maTau;
    private String maTuyen;
    private Date ngayKhoiHanh;
    private Time gioKhoiHanh;


    public Chuyen() {
    }

    public Chuyen(String maChuyen, String maTau, String maTuyen, Date ngayKhoiHanh, Time gioKhoiHanh) {
        this.maChuyen = maChuyen;
        this.maTau = maTau;
        this.maTuyen = maTuyen;
        this.ngayKhoiHanh = ngayKhoiHanh;
        this.gioKhoiHanh = gioKhoiHanh;
    }

    public String getMaChuyen() {
        return maChuyen;
    }

    public void setMaChuyen(String maChuyen) {
        this.maChuyen = maChuyen;
    }

    public String getMaTau() {
        return maTau;
    }

    public void setMaTau(String maTau) {
        this.maTau = maTau;
    }

    public String getMaTuyen() {
        return maTuyen;
    }

    public void setMaTuyen(String maTuyen) {
        this.maTuyen = maTuyen;
    }

    public Date getNgayKhoiHanh() {
        return ngayKhoiHanh;
    }

    public Time getGioKhoiHanh() {
        return gioKhoiHanh;
    }
}
