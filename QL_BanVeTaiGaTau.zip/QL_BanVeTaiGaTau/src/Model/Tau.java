/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author LEGION 5
 */
public class Tau {
    private int MaTau;
    private String TenTau;
    private int TongSoGhe;

    public Tau() {
    }

    public Tau(int MaTau, String TenTau, int TongSoGhe) {
        this.MaTau = MaTau;
        this.TenTau = TenTau;
        this.TongSoGhe = TongSoGhe;
    }

    public int getMaTau() {
        return MaTau;
    }

    public void setMaTau(int MaTau) {
        this.MaTau = MaTau;
    }

    public String getTenTau() {
        return TenTau;
    }

    public void setTenTau(String TenTau) {
        this.TenTau = TenTau;
    }

    public int getTongSoGhe() {
        return TongSoGhe;
    }

    public void setTongSoGhe(int TongSoGhe) {
        this.TongSoGhe = TongSoGhe;
    }
    
    
}
