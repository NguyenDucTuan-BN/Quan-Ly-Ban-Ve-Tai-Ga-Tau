/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author LEGION 5
 */
public class Ga {
    private int MaGa;
    private String TenGa;
    private String DiaChi;

    public Ga() {
    }

    public Ga(int MaGa, String TenGa, String DiaChi) {
        this.MaGa = MaGa;
        this.TenGa = TenGa;
        this.DiaChi = DiaChi;
    }

    public int getMaGa() {
        return MaGa;
    }

    public void setMaGa(int MaGa) {
        this.MaGa = MaGa;
    }

    public String getTenGa() {
        return TenGa;
    }

    public void setTenGa(String TenGa) {
        this.TenGa = TenGa;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }
    @Override
    public String toString() {
        return TenGa; // để ComboBox hiển thị tên ga
    }
    
}
