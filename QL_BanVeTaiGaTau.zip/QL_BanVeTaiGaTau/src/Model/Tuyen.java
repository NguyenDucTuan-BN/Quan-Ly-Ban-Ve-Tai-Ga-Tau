/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author LEGION 5
 */
public class Tuyen {
    private int MaTuyen;
    private String GaDi, GaDen;
    private int ThoiGianDuKien;

    public Tuyen() {
    }

    public Tuyen(int MaTuyen, String GaDi, String GaDen, int ThoiGianDuKien) {
        this.MaTuyen = MaTuyen;
        this.GaDi = GaDi;
        this.GaDen = GaDen;
        this.ThoiGianDuKien = ThoiGianDuKien;
    }

    public Tuyen(String GaDi, String GaDen, int ThoiGianDuKien) {
        this.GaDi = GaDi;
        this.GaDen = GaDen;
        this.ThoiGianDuKien = ThoiGianDuKien;
    }
    

    public int getMaTuyen() {
        return MaTuyen;
    }

    public void setMaTuyen(int MaTuyen) {
        this.MaTuyen = MaTuyen;
    }

    public String getGaDi() {
        return GaDi;
    }

    public void setGaDi(String GaDi) {
        this.GaDi = GaDi;
    }

    public String getGaDen() {
        return GaDen;
    }

    public void setGaDen(String GaDen) {
        this.GaDen = GaDen;
    }

    public int getThoiGianDuKien() {
        return ThoiGianDuKien;
    }

    public void setThoiGianDuKien(int ThoiGianDuKien) {
        this.ThoiGianDuKien = ThoiGianDuKien;
    }

    
    
}
