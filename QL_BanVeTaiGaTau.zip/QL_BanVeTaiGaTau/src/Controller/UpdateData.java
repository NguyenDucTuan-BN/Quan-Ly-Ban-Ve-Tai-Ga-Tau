package Controller;

import Model.ChuyenTau;
import Model.DBConnection;
import Model.HanhKhach;
import Model.TaiKhoan;
import Model.Tau;
import Model.Ga;
import Model.Tuyen;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class UpdateData {

    public static boolean updateTaiKhoan(TaiKhoan tk) {
        String sql = "UPDATE TaiKhoan SET MatKhau = ?, TenDangNhap = ? WHERE MaTK=? ";
        try ( Connection conn = DBConnection.getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(sql);) {
            stmt.setString(1, tk.getPass());
            stmt.setInt(3, tk.getMaTK());
            stmt.setString(2, tk.getUser());

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public static boolean updateHanhKhach(HanhKhach hk) {
        String sql = "UPDATE HanhKhach SET MaTK=?, HoTen=?, CCCD=?, NgaySinh=?, GioiTinh=?, DiaChi=?, SDT=? WHERE MaHK=?";
        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement ps = conn.prepareStatement(sql);) {
            if (hk.getMaTK() == 0) {
                ps.setNull(1, java.sql.Types.INTEGER);
            } else {
                ps.setInt(1, hk.getMaTK());
            }
            ps.setString(2, hk.getHoTen());
            ps.setString(3, hk.getCCCD());

            if (hk.getNgaySinh() != null) {
                ps.setDate(4, new java.sql.Date(hk.getNgaySinh().getTime()));
            } else {
                ps.setDate(4, null);
            }

            ps.setString(5, hk.getGioiTinh());
            ps.setString(6, hk.getDiaChi());
            ps.setString(7, hk.getSDT());
            ps.setInt(8, hk.getMaHk());

            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public static boolean updateTau(Tau tau) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "UPDATE Tau SET TenTau = ?, TongSoGhe = ? WHERE MaTau = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tau.getTenTau());
            ps.setInt(2, tau.getTongSoGhe());
            ps.setInt(3, tau.getMaTau());

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(UpdateData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public static boolean updateGa(Ga ga) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "UPDATE `ga` SET `MaGa`=?,`TenGa`=?,`DiaChi`=? WHERE MaGa=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, ga.getMaGa());
            ps.setString(2, ga.getTenGa());
            ps.setString(3, ga.getDiaChi());
            ps.setInt(4, ga.getMaGa());

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(UpdateData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    //Huỷ vé
    public static boolean huyVe(String pnr) {
    String sql = "UPDATE Ve SET TrangThai = 'DaHuy' WHERE PNR = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pnr);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            return false;
        }
    }
    
    public static void updateTuyen(Tuyen tuyen) {
        String sql = "UPDATE Tuyen SET MaGaDi = (SELECT MaGa FROM Ga WHERE TenGa = ?), " +
                     "MaGaDen = (SELECT MaGa FROM Ga WHERE TenGa = ?), " +
                     "ThoiGianDuKien = ? WHERE MaTuyen = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, tuyen.getGaDi());
            stmt.setString(2, tuyen.getGaDen());
            stmt.setInt(3, tuyen.getThoiGianDuKien());
            stmt.setInt(4, tuyen.getMaTuyen());
            stmt.executeUpdate();

        } catch (Exception ex) {
        }
    }
    
        public static void updateChuyenTau(ChuyenTau ct) {
            String tuyen = ct.getTuyen();  // VD: "Ga Hà Nội - Ga Sài Gòn"
            String tenTau = ct.getTau();

            int maTuyen = LoadData.getMaTuyenByTen(tuyen);
            int maTau = LoadData.getMaTauByTen(tenTau);

            if (maTuyen == -1 || maTau == -1) {
                JOptionPane.showMessageDialog(null, "Không tìm thấy mã tuyến hoặc mã tàu.");
                return;
            }
            String sql = "UPDATE ChuyenTau SET MaTuyen = ? ,MaTau  = ?, NgayKhoiHanh = ?, GioKhoiHanh = ?, LoaiVe = ?, GiaVe = ? WHERE MaChuyen = ?";
            try (Connection conn = DBConnection.getConnection(); 
                    PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, maTuyen);
                stmt.setInt(2, maTau);
                stmt.setDate(3, new java.sql.Date(ct.getNgayKhoiHanh().getTime()));
                stmt.setTime(4, ct.getGioKhoiHanh());
                stmt.setString(5, ct.getLoaiVe());
                stmt.setBigDecimal(6, ct.getGiaVe());
                stmt.setInt(7, ct.getMaChuyen());
                 stmt.executeUpdate();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Lỗi: " + e.getMessage());
            }
        }
        
        public static boolean hoanTienVe(int maVe) {
            String sqlSelect = """
                SELECT v.MaHK, v.MaChuyen, 
                       (SELECT GiaVe FROM ChuyenTau WHERE MaChuyen = v.MaChuyen AND LoaiVe = v.LoaiVe) AS GiaVe
                FROM Ve v 
                WHERE v.MaVe = ?
            """;

            String sqlInsert = """
                INSERT INTO GiaoDich (MaVe, MaHK, ThoiGian, LoaiGD, GiaTriGD) 
                VALUES (?, ?, NOW(), 'Hoàn', ?)
            """;

            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement psSelect = conn.prepareStatement(sqlSelect)) {

                psSelect.setInt(1, maVe);
                ResultSet rs = psSelect.executeQuery();

                if (rs.next()) {
                    int maHK = rs.getInt("MaHK");
                    double giaVe = rs.getDouble("GiaVe");

                    try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert)) {
                        psInsert.setInt(1, maVe);
                        psInsert.setInt(2, maHK);
                        psInsert.setDouble(3, -giaVe); // hoàn tiền -> âm

                        int affected = psInsert.executeUpdate();
                        return affected > 0;
                    }
                } else {
                    System.err.println("Không tìm thấy vé với mã: " + maVe);
                    return false;
                }
            } catch (SQLException e) {
                System.err.println("Lỗi SQL khi hoàn tiền vé: " + e.getMessage());
                return false;
            }
        }
        
    //14/7
        public static boolean yeuCauHuyVe(String maVe) {
        String sql = "UPDATE Ve SET TrangThai = ? WHERE MaVe = ?";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, "YeuCauHuy");
            ps.setString(2, maVe);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean capNhatTrangThaiVe(int maVe, String trangThaiMoi) {
        String sql = "UPDATE Ve SET TrangThai = ? WHERE MaVe = ?";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, trangThaiMoi);
            ps.setInt(2, maVe);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
