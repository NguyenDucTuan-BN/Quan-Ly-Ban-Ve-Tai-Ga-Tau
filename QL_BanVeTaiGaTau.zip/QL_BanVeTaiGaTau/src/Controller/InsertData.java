/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.ChuyenTau;
import Model.DBConnection;
import Model.Ga;
import Model.HanhKhach;
import Model.TaiKhoan;
import Model.Tau;
import Model.Tuyen;
import Model.Ve;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class InsertData {

    public static int insertTaiKhoan(TaiKhoan tk) {
        int maTK = -1;
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, tk.getUser());
            ps.setString(2, tk.getPass());
            ps.setString(3, tk.getRole());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                maTK = rs.getInt(1);
            }
        } catch (Exception e) {
        }
        return maTK;
    }

    public static boolean insertHanhKhachDK(HanhKhach hk, int maTK) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO hanhkhach (MaTK, HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maTK);
            ps.setString(2, hk.getHoTen());
            ps.setString(3, hk.getCCCD());
            ps.setDate(4, new java.sql.Date(hk.getNgaySinh().getTime()));
            ps.setString(5, hk.getGioiTinh());
            ps.setString(6, hk.getDiaChi());
            ps.setString(7, hk.getSDT());

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(InsertData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

//    public static boolean insertHanhKhach(HanhKhach hk) {
//        try {
//            Connection conn = DBConnection.getConnection();
//            // Câu lệnh SQL không có MaHK vì nó tự tăng trong DB
//            String sql = "INSERT INTO hanhkhach (MaTK, HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?, ?)";
//            PreparedStatement ps = conn.prepareStatement(sql);
//            ps.setInt(1, hk.getMaTK());
//            ps.setString(2, hk.getHoTen());
//            ps.setString(3, hk.getCCCD());
//            ps.setDate(4, new java.sql.Date(hk.getNgaySinh().getTime()));
//            ps.setString(5, hk.getGioiTinh());
//            ps.setString(6, hk.getDiaChi());
//            ps.setString(7, hk.getSDT());
//
//            return ps.executeUpdate() > 0;
//        } catch (SQLException ex) {
//            Logger.getLogger(InsertData.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return false;
//    }
//
//    public static int insertHanhKhachDatVe(HanhKhach hk) {
//        String sql = "INSERT INTO HanhKhach (HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?)";
//        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
//            ps.setString(1, hk.getHoTen());
//            ps.setString(2, hk.getCCCD());
//            ps.setDate(3, new java.sql.Date(hk.getNgaySinh().getTime()));
//            ps.setString(4, hk.getGioiTinh());
//            ps.setString(5, hk.getDiaChi());
//            ps.setString(6, hk.getSDT());
//            ps.executeUpdate();
//            ResultSet rs = ps.getGeneratedKeys();
//            if (rs.next()) {
//                return rs.getInt(1); // trả về MaHK vừa insert
//            }
//        } catch (Exception e) {
//        }
//        return -1; // thất bại
//    }

    public static boolean insertTau(Tau tau) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO Tau (MaTau, TenTau, TongSoGhe) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, tau.getMaTau());
            ps.setString(2, tau.getTenTau());
            ps.setInt(3, tau.getTongSoGhe());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(InsertData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public static boolean insertGa(Ga ga) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO `ga`(`MaGa`, `TenGa`, `DiaChi`) VALUES (?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, ga.getMaGa());
            ps.setString(2, ga.getTenGa());
            ps.setString(3, ga.getDiaChi());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(InsertData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public static boolean insertVe(Ve ve) {
        String sql = "INSERT INTO Ve (MaChuyen, SoGhe, LoaiVe, PNR, NgayDat, TrangThai, MaHK) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, ve.getMaChuyen());
            stmt.setString(2, ve.getSoGhe());
            stmt.setString(3, ve.getLoaiVe());
            stmt.setString(4, ve.getPNR());
            stmt.setDate(5, new java.sql.Date(ve.getNgayDat().getTime()));
            stmt.setString(6, ve.getTrangThai());
            stmt.setInt(7, ve.getMaHK()); 

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            return false;
        }
    }

//    public static int insertOrGetMaHK(HanhKhach hk) {
//        int maHK = getMaHKByCCCD(hk.getCCCD()); 
//        if (maHK != -1) {
//            return maHK; 
//        }
//        String sql = "INSERT INTO HanhKhach (HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?)";
//        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
//
//            stmt.setString(1, hk.getHoTen());
//            stmt.setString(2, hk.getCCCD());
//            stmt.setDate(3, new java.sql.Date(hk.getNgaySinh().getTime()));
//            stmt.setString(4, hk.getGioiTinh());
//            stmt.setString(5, hk.getDiaChi());
//            stmt.setString(6, hk.getSDT());
//
//            int affectedRows = stmt.executeUpdate();
//            if (affectedRows == 0) {
//                return -1;
//            }
//
//            ResultSet generatedKeys = stmt.getGeneratedKeys();
//            if (generatedKeys.next()) {
//                return generatedKeys.getInt(1);
//            }
//        } catch (SQLException e) {
//        }
//        return -1;
//    }
    
//    public static int insertOrGetMaHK(HanhKhach hk) {
//    int maHK = -1;
//
//    try (Connection conn = DBConnection.getConnection()) {
//        // Kiểm tra hành khách đã tồn tại chưa
//        String sqlCheck = "SELECT MaHK, MaTK FROM HanhKhach WHERE CCCD = ?";
//        PreparedStatement psCheck = conn.prepareStatement(sqlCheck);
//        psCheck.setString(1, hk.getCCCD());
//        ResultSet rs = psCheck.executeQuery();
//
//        if (rs.next()) {
//            maHK = rs.getInt("MaHK");
//            Integer maTK_DB = rs.getObject("MaTK") != null ? rs.getInt("MaTK") : null;
//
//            // Nếu MaTK trong DB đang null mà HanhKhach truyền vào có MaTK > 0 thì cập nhật
//            if (maTK_DB == null && hk.getMaTK() > 0) {
//                String sqlUpdate = "UPDATE HanhKhach SET MaTK = ? WHERE MaHK = ?";
//                PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate);
//                psUpdate.setInt(1, hk.getMaTK());
//                psUpdate.setInt(2, maHK);
//                psUpdate.executeUpdate();
//            }
//            return maHK;
//        }
//
//        // Nếu chưa tồn tại => Insert mới
//        String sqlInsert;
//        PreparedStatement stmt;
//
//        if (hk.getMaTK() > 0) {
//            sqlInsert = "INSERT INTO HanhKhach (MaTK, HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?, ?)";
//            stmt = conn.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
//            stmt.setInt(1, hk.getMaTK());
//            stmt.setString(2, hk.getHoTen());
//            stmt.setString(3, hk.getCCCD());
//            stmt.setDate(4, new java.sql.Date(hk.getNgaySinh().getTime()));
//            stmt.setString(5, hk.getGioiTinh());
//            stmt.setString(6, hk.getDiaChi());
//            stmt.setString(7, hk.getSDT());
//        } else {
//            sqlInsert = "INSERT INTO HanhKhach (HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?)";
//            stmt = conn.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
//            stmt.setString(1, hk.getHoTen());
//            stmt.setString(2, hk.getCCCD());
//            stmt.setDate(3, new java.sql.Date(hk.getNgaySinh().getTime()));
//            stmt.setString(4, hk.getGioiTinh());
//            stmt.setString(5, hk.getDiaChi());
//            stmt.setString(6, hk.getSDT());
//        }
//
//        int affectedRows = stmt.executeUpdate();
//        if (affectedRows > 0) {
//            ResultSet generatedKeys = stmt.getGeneratedKeys();
//            if (generatedKeys.next()) {
//                maHK = generatedKeys.getInt(1);
//            }
//        }
//
//    } catch (SQLException e) {
//        e.printStackTrace(); // In lỗi để dễ debug
//    }
//
//    return maHK;
//}

    
    public static void insertTuyen(Tuyen tuyen) {
        String sql = "INSERT INTO Tuyen (MaGaDi, MaGaDen, ThoiGianDuKien) " +
                     "SELECT ga1.MaGa, ga2.MaGa, ? " +
                     "FROM Ga ga1, Ga ga2 " +
                     "WHERE ga1.TenGa = ? AND ga2.TenGa = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, tuyen.getThoiGianDuKien());
            stmt.setString(2, tuyen.getGaDi());
            stmt.setString(3, tuyen.getGaDen());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(null, "Thêm tuyến thành công!");
            } else {
                JOptionPane.showMessageDialog(null, "Không tìm thấy ga!");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        } 
    }
    
    public static void insertChuyenTau(ChuyenTau ct) {
        String tuyen = ct.getTuyen();  // VD: "Ga Hà Nội - Ga Sài Gòn"
        String tenTau = ct.getTau();

        int maTuyen = LoadData.getMaTuyenByTen(tuyen);
        int maTau = LoadData.getMaTauByTen(tenTau);

        if (maTuyen == -1 || maTau == -1) {
            JOptionPane.showMessageDialog(null, "Không tìm thấy mã tuyến hoặc mã tàu.");
            return;
        }

        String sql = "INSERT INTO ChuyenTau (MaTuyen, MaTau, NgayKhoiHanh, GioKhoiHanh, LoaiVe, GiaVe) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, maTuyen);
            stmt.setInt(2, maTau);
            stmt.setDate(3, new java.sql.Date(ct.getNgayKhoiHanh().getTime()));
            stmt.setTime(4, ct.getGioKhoiHanh());
            stmt.setString(5, ct.getLoaiVe());
            stmt.setBigDecimal(6, ct.getGiaVe());

            stmt.executeUpdate();
            System.out.println("INSERT CHUYEN TAU: " + ct.getTuyen() + " - " + ct.getTau());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm chuyến: " + e.getMessage());
        }
    }
    
    public static boolean insertGiaoDich(int maVe, int maHK, int maChuyen) {
        String sql = "INSERT INTO GiaoDich (MaVe, MaHK, ThoiGian, LoaiGD, GiaTriGD) SELECT ?, ?, NOW(), 'Thanh toán', GiaVe FROM ChuyenTau WHERE MaChuyen = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, maVe);
            pstmt.setInt(2, maHK);
            pstmt.setInt(3, maChuyen);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }
    public static void luuBaoCaoVaoDatabase(int maChuyen, int SoVeDaBan, int SoGheConLai, double TongDoanhThu ) {
        String sql2 = "INSERT INTO BaoCao (MaChuyen, ThoiGian, SoVeDaBan, SoGheConLai, TongDoanhThu) VALUES(?, NOW(), ?, ?, ?)";
        try (var conn = DBConnection.getConnection();
             var ps = conn.prepareStatement(sql2)) {

                ps.setInt(1, maChuyen);
                ps.setInt(2, SoVeDaBan);
                ps.setInt(3, SoGheConLai);
                ps.setDouble(4, TongDoanhThu);



            int rows = ps.executeUpdate();
            if (rows > 0) {
                System.out.println("Đã lưu báo cáo vào CSDL.");
            }
        } catch (Exception e) {
        }
    }

    //14/7
    public static boolean insertHanhKhach(HanhKhach hk) {
        try {
            Connection conn = DBConnection.getConnection();
            // Câu lệnh SQL không có MaHK vì nó tự tăng trong DB
            String sql = "INSERT INTO hanhkhach (MaTK, HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, hk.getMaTK());
            ps.setString(2, hk.getHoTen());
            ps.setString(3, hk.getCCCD());
            ps.setDate(4, new java.sql.Date(hk.getNgaySinh().getTime()));
            ps.setString(5, hk.getGioiTinh());
            ps.setString(6, hk.getDiaChi());
            ps.setString(7, hk.getSDT());

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(InsertData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public static int insertHanhKhachDatVe(HanhKhach hk) {
        String sql = "INSERT INTO HanhKhach (HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, hk.getHoTen());
            ps.setString(2, hk.getCCCD());
            ps.setDate(3, new java.sql.Date(hk.getNgaySinh().getTime()));
            ps.setString(4, hk.getGioiTinh());
            ps.setString(5, hk.getDiaChi());
            ps.setString(6, hk.getSDT());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); // trả về MaHK vừa insert
            }
        } catch (Exception e) {
        }
        return -1; // thất bại
    }
    
    public static int insertOrGetMaHK(HanhKhach hk) {
        int maHK = -1;

        try (Connection conn = DBConnection.getConnection()) {
            // Kiểm tra hành khách đã tồn tại chưa
            String sqlCheck = "SELECT MaHK, MaTK FROM HanhKhach WHERE CCCD = ?";
            PreparedStatement psCheck = conn.prepareStatement(sqlCheck);
            psCheck.setString(1, hk.getCCCD());
            ResultSet rs = psCheck.executeQuery();

            if (rs.next()) {
                maHK = rs.getInt("MaHK");
                Integer maTK_DB = rs.getObject("MaTK") != null ? rs.getInt("MaTK") : null;

                // Nếu MaTK chưa có (null) và người dùng đăng nhập, thì cập nhật MaTK
                if (maTK_DB == null && hk.getMaTK() > 0) {
                    String sqlUpdate = "UPDATE HanhKhach SET MaTK = ? WHERE MaHK = ?";
                    PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate);
                    psUpdate.setInt(1, hk.getMaTK());
                    psUpdate.setInt(2, maHK);
                    psUpdate.executeUpdate();
                }
                return maHK; // Dù update hay không vẫn trả về
            }

            // Nếu chưa tồn tại => insert mới
            String sqlInsert = "INSERT INTO HanhKhach (MaTK, HoTen, CCCD, NgaySinh, GioiTinh, DiaChi, SDT) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, hk.getMaTK());
            stmt.setString(2, hk.getHoTen());
            stmt.setString(3, hk.getCCCD());
            stmt.setDate(4, new java.sql.Date(hk.getNgaySinh().getTime()));
            stmt.setString(5, hk.getGioiTinh());
            stmt.setString(6, hk.getDiaChi());
            stmt.setString(7, hk.getSDT());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    maHK = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {        
            
        }
        return maHK;
    }
}
