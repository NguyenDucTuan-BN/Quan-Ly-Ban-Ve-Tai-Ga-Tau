/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.BaoCao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Model.ChuyenTau;
import Model.DBConnection;
import Model.Ga;
import Model.HanhKhach;
import Model.TaiKhoan;
import Model.Tau;
import Model.ThongTinVe;
import Model.Tuyen;
import Model.Ve;
import java.util.ArrayList;
import java.sql.*;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author nguyenductuan
 */
public class LoadData extends DBConnection {
    public static ArrayList<TaiKhoan> getAllTaiKhoan() {
        ArrayList<TaiKhoan> list = new ArrayList<>();
        try {
            PreparedStatement pre = getConnection().prepareStatement("select * from TaiKhoan");
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                TaiKhoan c = new TaiKhoan(
                        rs.getInt(1),
                        rs.getString(2).trim(),
                        rs.getString(3).trim(),
                        rs.getString(4).trim()
                );
                list.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public static ArrayList<HanhKhach> getAllHanhKhach() {
        ArrayList<HanhKhach> list = new ArrayList<>();
        try {
            PreparedStatement pre = getConnection().prepareStatement("select * from HanhKhach");
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                HanhKhach hk = new HanhKhach(
                        rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3).trim(),
                        rs.getString(4).trim(),
                        rs.getDate(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8)
                );
                list.add(hk);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    public static ArrayList<Tau> getAllTau() {
        ArrayList<Tau> list = new ArrayList<>();
        try {
            PreparedStatement pre = getConnection().prepareStatement("select * from Tau");
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                Tau tau = new Tau(
                        rs.getInt(1),
                        rs.getString(2).trim(),
                        rs.getInt(3)
                );
                list.add(tau);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    

    public static ArrayList<Ga> getAllGa() {
        ArrayList<Ga> list = new ArrayList<>();
        try {
            PreparedStatement pre = getConnection().prepareStatement("select * from Ga");
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                Ga ga = new Ga(
                        rs.getInt(1),
                        rs.getString(2).trim(),
                        rs.getString(3).trim()
                );
                list.add(ga);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
        public static ArrayList<Tuyen> getAllTuyen() {
        ArrayList<Tuyen> list = new ArrayList<>();
        try {
            String sql = "SELECT t.MaTuyen, ga_di.TenGa AS GaDi, ga_den.TenGa AS GaDen, t.ThoiGianDuKien " +
             "FROM Tuyen t " +
             "JOIN Ga ga_di ON t.MaGaDi = ga_di.MaGa " +
             "JOIN Ga ga_den ON t.MaGaDen = ga_den.MaGa";
            PreparedStatement pre = getConnection().prepareStatement(sql);
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                Tuyen tuyen = new Tuyen(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getInt(4)
                );
                list.add(tuyen);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
        
    public static ArrayList<ChuyenTau> getAllChuyenTau() {
        ArrayList<ChuyenTau> list = new ArrayList<>();
        try {
            String sql = "SELECT ct.MaChuyen, " +
             "CONCAT(ga_di.TenGa, ' - ', ga_den.TenGa) AS TuyenDuong, " +
             "tau.TenTau, ct.NgayKhoiHanh, ct.GioKhoiHanh, ct.LoaiVe, ct.GiaVe " +
             "FROM ChuyenTau ct " +
             "JOIN Tuyen t ON ct.MaTuyen = t.MaTuyen " +
             "JOIN Ga ga_di ON t.MaGaDi = ga_di.MaGa " +
             "JOIN Ga ga_den ON t.MaGaDen = ga_den.MaGa " +
             "JOIN Tau tau ON ct.MaTau = tau.MaTau";
            PreparedStatement pre = getConnection().prepareStatement(sql);
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                ChuyenTau ct = new ChuyenTau(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDate(4),
                        rs.getTime(5),
                        rs.getString(6),
                        rs.getBigDecimal(7)
                );
                list.add(ct);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public static ArrayList<Ve> getAllVeTau() {
        ArrayList<Ve> list = new ArrayList<>();
        try {
            PreparedStatement pre = getConnection().prepareStatement("select * from Ve");
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                Ve ve = new Ve(
                        rs.getInt(1),
                        rs.getInt(2),
                        rs.getInt(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getDate(7),
                        rs.getString(8)
                );
                list.add(ve);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public static Map<String, Boolean> loadDanhSachGhe(int maTau, int maChuyen) throws Exception {
        int tongSoGhe = LoadData.getTongSoGhe(maTau);
        if (tongSoGhe == 0) {
            throw new Exception("Không tìm thấy số ghế!");
        }

        Set<String> gheDaDat = LoadData.getGheDaDat(maChuyen);

        int gheMoiHang = 10;
        Map<String, Boolean> gheMap = new LinkedHashMap<>();
        int gheDaTao = 0;

        for (int hang = 0; gheDaTao < tongSoGhe; hang++) {
            char tenHang = (char) ('A' + hang);
            for (int i = 1; i <= gheMoiHang && gheDaTao < tongSoGhe; i++) {
                String tenGhe = tenHang + String.format("%02d", i);
                boolean daDat = gheDaDat.contains(tenGhe);
                gheMap.put(tenGhe, daDat);
                gheDaTao++;
            }
        }

        return gheMap; // key = tên ghế, value = đã đặt hay chưa
    }

    public static HanhKhach getAllHKByMaHK(int maTK) {
        HanhKhach hk = null;
        String sql = "SELECT * FROM HanhKhach WHERE MaTK = ?";
        try (
            PreparedStatement stmt = getConnection().prepareStatement(sql);) {
            stmt.setInt(1, maTK);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                hk = new HanhKhach();
                hk.setMaHk(rs.getInt("MaHK")); 
                hk.setMaTK(maTK);
                hk.setHoTen(rs.getString("HoTen"));
                hk.setCCCD(rs.getString("CCCD"));
                hk.setGioiTinh(rs.getString("GioiTinh"));
                hk.setDiaChi(rs.getString("DiaChi"));
                hk.setSDT(rs.getString("SDT"));
                hk.setNgaySinh(rs.getDate("NgaySinh"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return hk;
    }
    
    public static TaiKhoan getAllTKByMaTK(int maTK) {
        TaiKhoan tk = null;
        String sql = "SELECT * FROM TaiKhoan WHERE MaTK = ?";
        try ( 
            PreparedStatement stmt = getConnection().prepareStatement(sql);) {
            stmt.setInt(1, maTK);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                tk = new TaiKhoan();
                tk.setUser(rs.getString("TenDangNhap"));
                tk.setPass(rs.getString("MatKhau"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tk;
    }

    public static ArrayList<Object[]> timKiemChuyenTau(String maGaDi, String maGaDen, Date ngayDi) {
        ArrayList<Object[]> list = new ArrayList<>();
        try {
            String sql = "SELECT ct.MaChuyen, t.TenTau, g1.TenGa AS GaDi, g2.TenGa AS GaDen, "
                    + "ct.NgayKhoiHanh, ct.GioKhoiHanh, ct.LoaiVe, ct.GiaVe "
                    + "FROM ChuyenTau ct "
                    + "JOIN Tuyen tu ON ct.MaTuyen = tu.MaTuyen "
                    + "JOIN Ga g1 ON tu.MaGaDi = g1.MaGa "
                    + "JOIN Ga g2 ON tu.MaGaDen = g2.MaGa "
                    + "JOIN Tau t ON ct.MaTau = t.MaTau "
                    + "WHERE tu.MaGaDi = ? AND tu.MaGaDen = ? AND ct.NgayKhoiHanh = ?";
            PreparedStatement ps = getConnection().prepareStatement(sql);
            ps.setString(1, maGaDi);
            ps.setString(2, maGaDen);
            ps.setDate(3, new java.sql.Date(ngayDi.getTime()));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("MaChuyen"),
                    rs.getString("TenTau"),
                    rs.getString("GaDi"),
                    rs.getString("GaDen"),
                    rs.getDate("NgayKhoiHanh"),
                    rs.getTime("GioKhoiHanh"),
                    rs.getString("LoaiVe"),
                    rs.getDouble("GiaVe")
                };
                list.add(row);
            }
        } catch (SQLException e) {
        }
        return list;
    }

    public static int getTongSoGhe(int maTau) throws SQLException {
        String sql = "SELECT TongSoGhe FROM Tau WHERE MaTau = ?";
        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement st = conn.prepareStatement(sql)) {
            st.setInt(1, maTau);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return rs.getInt("TongSoGhe");
            }
        }
        return 0;
    }

    public static Set<String> getGheDaDat(int maChuyen) throws SQLException {
        Set<String> gheDaDat = new HashSet<>();
        String sql = "SELECT SoGhe FROM Ve WHERE MaChuyen = ? AND TrangThai = 'DaDat'";
        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement st = conn.prepareStatement(sql)) {
            st.setInt(1, maChuyen);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                gheDaDat.add(rs.getString("SoGhe").toUpperCase());
            }
        }
        return gheDaDat;
    }

    public static int getMaHKByCCCD(String cccd) {
        String sql = "SELECT MaHK FROM HanhKhach WHERE CCCD = ?";
        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cccd);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("MaHK");
            }
        } catch (SQLException e) {
        }
        return -1; // không tìm thấy
    }
    
    //Lấy thông tin vé
    public static ThongTinVe getVeByMaVe(String PNR) {
        ThongTinVe ve = null;
        String sql = "SELECT v.MaVe, v.PNR, t.TenTau, v.SoGhe, ct.GioKhoiHanh, ct.NgayKhoiHanh, " +
             "gdi.TenGa AS GaDi, gden.TenGa AS GaDen, ct.GiaVe, v.TrangThai " +
             "FROM Ve v " +
             "JOIN ChuyenTau ct ON v.MaChuyen = ct.MaChuyen " +
             "JOIN Tau t ON ct.MaTau = t.MaTau " +
             "JOIN Tuyen tuy ON ct.MaTuyen = tuy.MaTuyen " +
             "JOIN Ga gdi ON tuy.MaGaDi = gdi.MaGa " +
             "JOIN Ga gden ON tuy.MaGaDen = gden.MaGa " +
             "WHERE v.PNR = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, PNR);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ve = new ThongTinVe();
                ve.setMaVe(rs.getInt("MaVe"));
                ve.setPnr(rs.getString("PNR"));
                ve.setTenTau(rs.getString("TenTau"));
                ve.setSoGhe(rs.getString("SoGhe"));
                ve.setGioDi(rs.getString("GioKhoiHanh"));
                ve.setNgayDat(rs.getDate("NgayKhoiHanh"));
                ve.setGiaVe(rs.getBigDecimal("GiaVe"));
                ve.setTrangThai(rs.getString("TrangThai"));
                ve.setGaDi(rs.getString("GaDi"));
                ve.setGaDen(rs.getString("GaDen"));
            }

        } catch (SQLException e) {
        }

        return ve;
    }
    
    public static ArrayList<String> getAllTuyenDuong() {
        ArrayList<String> list = new ArrayList<>();
        String sql = "SELECT CONCAT(ga1.TenGa, ' - ', ga2.TenGa) AS TuyenDuong " +
                     "FROM Tuyen t " +
                     "JOIN Ga ga1 ON t.MaGaDi = ga1.MaGa " +
                     "JOIN Ga ga2 ON t.MaGaDen = ga2.MaGa";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(rs.getString("TuyenDuong"));
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    public static ArrayList<String> getAllTenTau() {
        ArrayList<String> tenTauList = new ArrayList<>();
        for (Tau tau : getAllTau()) {
            tenTauList.add(tau.getTenTau());
        }
        return tenTauList;
    }
    
    public static int getMaTuyenByTen(String tuyenDuong) {
        String sql = "SELECT MaTuyen FROM Tuyen t " +
                     "JOIN Ga ga1 ON t.MaGaDi = ga1.MaGa " +
                     "JOIN Ga ga2 ON t.MaGaDen = ga2.MaGa " +
                     "WHERE CONCAT(ga1.TenGa, ' - ', ga2.TenGa) = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tuyenDuong);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("MaTuyen");
            }
        } catch (SQLException e) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, e);
        }
        return -1;
    }

    public static int getMaTauByTen(String tenTau) {
        String sql = "SELECT MaTau FROM Tau WHERE TenTau = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tenTau);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("MaTau");
            }
        } catch (SQLException e) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, e);
        }
        return -1;
    }
    
    //Báo cáo:
    public static BaoCao layThongKe(int maChuyen) {
        try (Connection conn = getConnection()) {
            String sql = "SELECT " +
                         "(SELECT COUNT(*) FROM Ve WHERE MaChuyen = ? AND TrangThai != 'DaHuy') AS SoVeDaBan, " +
                         "(SELECT t.TongSoGhe - COUNT(v.MaVe) " +
                         " FROM Tau t " +
                         " JOIN ChuyenTau c ON c.MaTau = t.MaTau " +
                         " LEFT JOIN Ve v ON v.MaChuyen = c.MaChuyen AND v.TrangThai != 'DaHuy' " +
                         " WHERE c.MaChuyen = ?) AS SoGheConLai, " +
                         "(SELECT IFNULL(SUM(GiaTriGD), 0) " +
                         " FROM GiaoDich " +
                         " WHERE MaVe IN (SELECT MaVe FROM Ve WHERE MaChuyen = ? AND TrangThai != 'DaHuy')) AS TongDoanhThu";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maChuyen);
            ps.setInt(2, maChuyen);
            ps.setInt(3, maChuyen);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new BaoCao(
                    rs.getInt("SoVeDaBan"),
                    rs.getInt("SoGheConLai"),
                    rs.getDouble("TongDoanhThu")
                );
            }
        } catch (Exception e) {
            // Đừng để trống ở catch!

        }
        return null;
    }


    public static List<HanhKhach> layDSHanhKhach(int maChuyen, int[] soVeDaHuy) {
        List<HanhKhach> list = new ArrayList<>();
        try (Connection conn = getConnection()) {
            String sql = "SELECT hk.HoTen, hk.CCCD, hk.SDT, v.TrangThai " +
                         "FROM Ve v JOIN HanhKhach hk ON v.MaHK = hk.MaHK " +
                         "WHERE v.MaChuyen = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maChuyen);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String trangThai = rs.getString("TrangThai");
                if (trangThai != null && trangThai.equalsIgnoreCase("DaHuy")) {
                    soVeDaHuy[0]++;
                } else {
                    list.add(new HanhKhach(
                        rs.getString("HoTen"),
                        rs.getString("CCCD"),
                        rs.getString("SDT")
                    ));
                }
            }
        } catch (Exception e) {
        }
        return list;
    }  
    
    public static int getMaVeByPNR(String PNR) {
       String sql = "SELECT MaVe FROM Ve WHERE PNR = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, PNR);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("MaVe");
            }
        } catch (SQLException e) {
        }
        return -1;
    }

    public static List<ThongTinVe> getVeByMaTK(int maTK) {
        List<ThongTinVe> danhSach = new ArrayList<>();

        String sql = "SELECT v.MaVe, v.PNR, v.SoGhe, v.TrangThai, v.NgayDat, "
                + "t.TenTau, c.GioKhoiHanh AS GioDi, ga1.TenGa AS GaDi, ga2.TenGa AS GaDen, "
                + "c.GiaVe "
                + "FROM Ve v "
                + "JOIN ChuyenTau c ON v.MaChuyen = c.MaChuyen "
                + "JOIN Tau t ON c.MaTau = t.MaTau "
                + "JOIN Tuyen tu ON c.MaTuyen = tu.MaTuyen "
                + "JOIN Ga ga1 ON tu.MaGaDi = ga1.MaGa "
                + "JOIN Ga ga2 ON tu.MaGaDen = ga2.MaGa "
                + "JOIN HanhKhach hk ON v.MaHK = hk.MaHK "
                + "WHERE hk.MaTK = ?";

        try (Connection conn = getConnection(); 
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maTK);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ThongTinVe ve = new ThongTinVe(
                            rs.getInt("MaVe"),
                            rs.getString("PNR"),
                            rs.getString("TenTau"),
                            rs.getString("SoGhe"),
                            rs.getString("GioDi"),
                            rs.getDate("NgayDat"),
                            rs.getString("GaDi"),
                            rs.getString("GaDen"),
                            rs.getBigDecimal("GiaVe"),
                            rs.getString("TrangThai")
                    );
                    danhSach.add(ve);
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách vé theo MaTK = " + maTK);
        }

        return danhSach;
    }

    public static List<String> getAllGaDi() {
        List<String> listGaDi = new ArrayList<>();
        String sql = "SELECT DISTINCT ga_di.TenGa "
                + "FROM Tuyen t "
                + "JOIN Ga ga_di ON t.MaGaDi = ga_di.MaGa";
        try (PreparedStatement ps = getConnection().prepareStatement(sql); 
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                listGaDi.add(rs.getString("TenGa").trim());
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listGaDi;
    }

    public static List<String> getAllGaDen() {
        List<String> listGaDen = new ArrayList<>();
        String sql = "SELECT DISTINCT ga_den.TenGa "
                + "FROM Tuyen t "
                + "JOIN Ga ga_den ON t.MaGaDen = ga_den.MaGa";
        try (PreparedStatement ps = getConnection().prepareStatement(sql); 
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                listGaDen.add(rs.getString("TenGa").trim());
            }
        } catch (SQLException ex) {Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listGaDen;
    }

    public static List<ThongTinVe> getDanhSachYeuCauHuy() {
        List<ThongTinVe> danhSach = new ArrayList<>();
        String sql = "SELECT v.MaVe, v.PNR, v.SoGhe, v.TrangThai, v.NgayDat, "
                + "t.TenTau, c.GioKhoiHanh AS GioDi, ga1.TenGa AS GaDi, ga2.TenGa AS GaDen, "
                + "c.GiaVe "
                + "FROM Ve v "
                + "JOIN ChuyenTau c ON v.MaChuyen = c.MaChuyen "
                + "JOIN Tau t ON c.MaTau = t.MaTau "
                + "JOIN Tuyen tu ON c.MaTuyen = tu.MaTuyen "
                + "JOIN Ga ga1 ON tu.MaGaDi = ga1.MaGa "
                + "JOIN Ga ga2 ON tu.MaGaDen = ga2.MaGa "
                + "WHERE v.TrangThai = N'YeuCauHuy'";

        try (PreparedStatement ps = getConnection().prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ThongTinVe ve = new ThongTinVe();
                ve.setMaVe(rs.getInt("MaVe"));
                ve.setPnr(rs.getString("PNR"));
                ve.setTenTau(rs.getString("TenTau"));
                ve.setGaDi(rs.getString("GaDi"));
                ve.setGaDen(rs.getString("GaDen"));

                java.sql.Time gioDiSql = rs.getTime("GioDi");
                String gioDiStr = null;
                if (gioDiSql != null) {
                    gioDiStr = gioDiSql.toString(); // hoặc format nếu muốn
                }
                ve.setGioDi(gioDiStr);

                ve.setSoGhe(rs.getString("SoGhe"));
                ve.setGiaVe(rs.getBigDecimal("GiaVe"));
                ve.setNgayDat(rs.getDate("NgayDat"));
                ve.setTrangThai(rs.getString("TrangThai"));

                danhSach.add(ve);
            }

        } catch (SQLException e) {
        }

        return danhSach;
    }

    public static double getGiaVe(int maChuyen, String loaiVe) {
        double giaVe = -1;
        String sql = "SELECT GiaVe FROM ChuyenTau WHERE MaChuyen = ? AND LoaiVe = ?";
        try {
            PreparedStatement stmt = getConnection().prepareStatement(sql);
            stmt.setInt(1, maChuyen);
            stmt.setString(2, loaiVe);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                giaVe = rs.getDouble("GiaVe");
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return giaVe;
    }

    public static String layTrangThaiVe(String maVe) {
        String trangThai = "";
        String sql = "SELECT TrangThai FROM Ve WHERE MaVe = ?";
        try {
            PreparedStatement ps = getConnection().prepareStatement(sql);
            ps.setString(1, maVe);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                trangThai = rs.getString("TrangThai");
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoadData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return trangThai;
    }

    
}
