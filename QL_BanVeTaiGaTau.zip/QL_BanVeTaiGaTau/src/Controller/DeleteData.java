/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.DBConnection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author nguyenductuan
 */
public class DeleteData {

    public static boolean deleteTaiKhoan(int maTK) {
        String checkSQL = "SELECT * FROM HanhKhach WHERE MaTK = ?";
        String deleteHanhKhachSQL = "DELETE FROM HanhKhach WHERE MaTK = ?";
        String deleteTaiKhoanSQL = "DELETE FROM TaiKhoan WHERE MaTK = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkSQL)) {

            // Kiểm tra ràng buộc
            checkStmt.setInt(1, maTK);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                // Nếu có liên kết, hỏi người dùng có muốn xoá cả HanhKhach không
                int confirm = JOptionPane.showConfirmDialog(null,
                    "Tài khoản này đang liên kết với bảng Hành Khách.\nBạn có muốn xóa cả dữ liệu liên quan?",
                    "Xác nhận xóa sâu", JOptionPane.YES_NO_OPTION);

                if (confirm != JOptionPane.YES_OPTION) {
                    return false;
                }

                // Xoá cả HanhKhach và TaiKhoan
                conn.setAutoCommit(false); // Bắt đầu giao dịch

                try (PreparedStatement deleteHK = conn.prepareStatement(deleteHanhKhachSQL);
                     PreparedStatement deleteTK = conn.prepareStatement(deleteTaiKhoanSQL)) {

                    deleteHK.setInt(1, maTK);
                    deleteHK.executeUpdate();

                    deleteTK.setInt(1, maTK);
                    int rows = deleteTK.executeUpdate();

                    conn.commit(); // Xác nhận giao dịch
                    return rows > 0;

                } catch (SQLException ex) {
                    conn.rollback(); // Nếu lỗi, huỷ giao dịch
                    return false;
                }

            } else {
                // Nếu không có liên kết, chỉ cần xoá trong TaiKhoan
                try (PreparedStatement deleteTK = conn.prepareStatement(deleteTaiKhoanSQL)) {
                    deleteTK.setInt(1, maTK);
                    return deleteTK.executeUpdate() > 0;
                }
            }

        } catch (SQLException ex) {
            return false;
        }
    }

    public static boolean deleteTau(int maTau) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "DELETE FROM Tau WHERE MaTau = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maTau);

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DeleteData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public static boolean deleteGa(int maGa) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "DELETE FROM `ga` WHERE MaGa=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maGa);

            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DeleteData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public static boolean deleteHanhKhach(int maHK) {
        String sqlDeleteGiaoDich = "DELETE FROM GiaoDich WHERE MaVe IN (SELECT MaVe FROM Ve WHERE MaHK = ?)";
        String sqlDeleteVe = "DELETE FROM Ve WHERE MaHK = ?";
        String sqlDeleteHanhKhach = "DELETE FROM HanhKhach WHERE MaHK = ?";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false); // Bắt đầu transaction

            // 1. Xoá giao dịch liên quan đến vé của hành khách
            try (PreparedStatement ps1 = conn.prepareStatement(sqlDeleteGiaoDich)) {
                ps1.setInt(1, maHK);
                ps1.executeUpdate();
            }

            // 2. Xoá vé của hành khách
            try (PreparedStatement ps2 = conn.prepareStatement(sqlDeleteVe)) {
                ps2.setInt(1, maHK);
                ps2.executeUpdate();
            }

            // 3. Xoá hành khách
            try (PreparedStatement ps3 = conn.prepareStatement(sqlDeleteHanhKhach)) {
                ps3.setInt(1, maHK);
                int rows = ps3.executeUpdate();
                conn.commit(); // Commit nếu tất cả đều thành công
                return rows > 0;
            }

        } catch (SQLException e) { // In lỗi để dễ debug
            // In lỗi để dễ debug
            return false;
        }
    }
   
    public static void deleteTuyen(int maTuyen) {
        String sql = "DELETE FROM Tuyen WHERE MaTuyen = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, maTuyen);
            stmt.executeUpdate();
        } catch (Exception ex) {
        }
    }
    public static void deleteChuyenTau(int maChuyen) {
        String sql = "DELETE FROM ChuyenTau WHERE MaChuyen = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, maChuyen);
            stmt.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + e.getMessage());
        }
    }

}
