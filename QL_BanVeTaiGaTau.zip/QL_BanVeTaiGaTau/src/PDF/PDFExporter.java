package PDF;

import Model.BaoCao;
import Model.HanhKhach;
import java.io.IOException;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

public class PDFExporter {

    public static void xuatPDF(String path, int maChuyen, BaoCao baoCao, List<HanhKhach> hanhKhachList, String tuyen, String ngayKH, String tenTau, int soVeDaHuy) {
        if (!path.toLowerCase().endsWith(".pdf")) {
            path += ".pdf";
        }

        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            doc.addPage(page);

            PDPageContentStream content = new PDPageContentStream(doc, page);
            float marginLeft = 50;
            float y = 750;

            var fontBold = PDType1Font.HELVETICA_BOLD;
            var font = PDType1Font.HELVETICA;

            // Tiêu đề
            content.beginText();
            content.setFont(fontBold, 16);
            content.newLineAtOffset(marginLeft, y);
            content.showText("BAO CAO CHUYEN TAU");
            content.endText();
            y -= 30;

            // Thông tin chuyến tàu
            content.beginText();
            content.setFont(font, 12);
            content.newLineAtOffset(marginLeft, y);

            content.showText("Ma chuyen: " + maChuyen);
            content.newLineAtOffset(0, -20);

            content.showText("Tuyen: " + removeVietnamese(tuyen));
            content.newLineAtOffset(0, -20);

            content.showText("Ngay khoi hanh: " + ngayKH);
            content.newLineAtOffset(0, -20);

            content.showText("Ten tau: " + removeVietnamese(tenTau));
            content.endText();
            y -= 100;

            // Thông tin tổng hợp
            content.beginText();
            content.setFont(font, 12);
            content.newLineAtOffset(marginLeft, y);

            content.showText("So ve da ban: " + baoCao.getSoVeDaBan());
            content.newLineAtOffset(0, -20);

            content.showText("So ve da huy: " + soVeDaHuy);
            content.newLineAtOffset(0, -20);

            content.showText("So ghe con lai: " + baoCao.getSoGheConLai());
            content.newLineAtOffset(0, -20);

            content.showText("Tong doanh thu: " + baoCao.getTongDoanhThu() + " VND");
            content.endText();
            y -= 90;

            // Danh sách hành khách
            content.beginText();
            content.setFont(fontBold, 13);
            content.newLineAtOffset(marginLeft, y);
            content.showText("Danh sach hanh khach:");
            content.endText();
            y -= 20;

            for (HanhKhach hk : hanhKhachList) {
                if (y < 70) {
                    content.close();
                    page = new PDPage(PDRectangle.A4);
                    doc.addPage(page);
                    content = new PDPageContentStream(doc, page);
                    y = 750;
                }

                content.beginText();
                content.setFont(font, 11);
                content.newLineAtOffset(marginLeft, y);

                String hoTen = removeVietnamese(hk.getHoTen());
                String cccd = hk.getCCCD();
                String sdt = hk.getSDT();

                content.showText(hoTen + " | CCCD: " + cccd + " | SDT: " + sdt);
                content.endText();
                y -= 20;
            }

            content.close();
            doc.save(path);
            System.out.println("File PDF da duoc luu: " + path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

// Hàm loại bỏ dấu tiếng Việt
    private static String removeVietnamese(String str) {
        String[][] vietChars = {
            {"a", "á", "à", "ả", "ã", "ạ", "ă", "ắ", "ằ", "ẳ", "ẵ", "ặ", "â", "ấ", "ầ", "ẩ", "ẫ", "ậ"},
            {"A", "Á", "À", "Ả", "Ã", "Ạ", "Ă", "Ắ", "Ằ", "Ẳ", "Ẵ", "Ặ", "Â", "Ấ", "Ầ", "Ẩ", "Ẫ", "Ậ"},
            {"d", "đ"}, {"D", "Đ"},
            {"e", "é", "è", "ẻ", "ẽ", "ẹ", "ê", "ế", "ề", "ể", "ễ", "ệ"},
            {"E", "É", "È", "Ẻ", "Ẽ", "Ẹ", "Ê", "Ế", "Ề", "Ể", "Ễ", "Ệ"},
            {"i", "í", "ì", "ỉ", "ĩ", "ị"},
            {"I", "Í", "Ì", "Ỉ", "Ĩ", "Ị"},
            {"o", "ó", "ò", "ỏ", "õ", "ọ", "ô", "ố", "ồ", "ổ", "ỗ", "ộ", "ơ", "ớ", "ờ", "ở", "ỡ", "ợ"},
            {"O", "Ó", "Ò", "Ỏ", "Õ", "Ọ", "Ô", "Ố", "Ồ", "Ổ", "Ỗ", "Ộ", "Ơ", "Ớ", "Ờ", "Ở", "Ỡ", "Ợ"},
            {"u", "ú", "ù", "ủ", "ũ", "ụ", "ư", "ứ", "ừ", "ử", "ữ", "ự"},
            {"U", "Ú", "Ù", "Ủ", "Ũ", "Ụ", "Ư", "Ứ", "Ừ", "Ử", "Ữ", "Ự"},
            {"y", "ý", "ỳ", "ỷ", "ỹ", "ỵ"},
            {"Y", "Ý", "Ỳ", "Ỷ", "Ỹ", "Ỵ"}
        };
        for (String[] group : vietChars) {
            for (int i = 1; i < group.length; i++) {
                str = str.replace(group[i], group[0]);
            }
        }
        return str;
    }

}
